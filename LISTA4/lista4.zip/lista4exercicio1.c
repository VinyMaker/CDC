#include <stdio.h>
#include <stdlib.h>

int main()
{
    int L,M,N;
    printf("Digite 3 valores para ordenar:");
    scanf("%d %d %d", &L,&M,&N);
    if (L < N && L < M){
        if(N<M){
            printf("%d %d %d",L,N,M);
        }
        else{
            printf("%d %d %d",L,M,N);
        }
    }
    if (N < L && N < M){
        if(L < M){
            printf("%d %d %d", N,L,M);
        }
        else{
            printf("%d %d %d", N,M,L);
            }
    }
    if (M < N && M < L){
        if (N < L){
            printf("%d %d %d", M,N,L);
        }
        else{
            printf("%d %d %d", M,L,N);
            }
    }
    return 0;
    }