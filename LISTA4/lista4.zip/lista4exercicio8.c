#include <stdio.h>
#include <stdlib.h>


int main()
{
	float custofinal=0,custofabrica=0,taxatotal,taxadistribuidor,impostos;

	printf("Digite o Custo de Fabrica do Veiculo:\n");
	scanf("%f",&custofabrica);
	printf("Digite a taxa (em porcentagem) cobrada pelo distribuidor:\n");
	scanf("%f",&taxadistribuidor);
	printf("Digite a taxa (em porcentagem) de impostos:\n");
	scanf("%f",&impostos);

	taxadistribuidor = taxadistribuidor / 100;
	impostos = impostos / 100;

	taxatotal = taxadistribuidor + impostos;

	custofinal = custofabrica + (custofabrica * taxatotal);

	printf("O custo final ao cunsumidor sera de R$ %2.f ",custofinal);

return 0;
}
