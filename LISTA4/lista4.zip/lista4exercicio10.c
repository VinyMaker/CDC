#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main()
{
	float numeros[4];
	int i;
	printf("CUBO DE 400 NUMEROS, numeros de ordem em ordinal:\n\n");
	for(i=1;i<401;i++){
		printf("Digite o %d numero: ",i);
		scanf("%f",&numeros[i]);
}
	for(i=1;i<401;i++){
		printf("O cubo do %d numero e %2.f\n",i,pow(numeros[i],3));
}
return 0;
}
