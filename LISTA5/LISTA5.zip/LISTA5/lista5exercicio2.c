#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {

	float salario,novo_salario, bonus=0;
	bonus = 0.15;
    printf("===============================\n");
	printf("Reajuste Salarial de %.f por cento:\nDigite o salário para reajuste:\n",bonus*100);
	printf("===============================\n");

	scanf("%f",&salario);

	if(salario<500){
        novo_salario = salario + (salario*bonus);
        printf("O novo salário será de R$ %.2f\nTenha um bom dia!",novo_salario);
	}
	else{
        printf("Sem direio a reajuste. :(\nTenha um bom dia!");
	}
}

